﻿chmod 755 ./sdsetup-backend
sudo ./sdsetup-backend --urls http://*:5000